#!/usr/bin/env bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BSP_DIR="$( cd "${SCRIPT_DIR}/../" && pwd )"

# x264 patch
cd ${BSP_DIR}/meta-oe/meta-oe/recipes-multimedia/x264/
sed -i 's|1cffe9f406cc54f4759fc9eeb85598fb8cae66c7|bfed708c5358a2b4ef65923fb0683cefa9184e6f|' x264_git.bb

# OpenCV patch
cd ${BSP_DIR}/meta-oe/meta-oe/recipes-support/opencv/
sed -i 's|OpenCV-|opencv-|' opencv_2.4.3.bb
sed -i 's|^SRC_URI =.*|SRC_URI = "https://github.com/Itseez/opencv/archive/${PV}.tar.gz \\|' opencv_2.4.3.bb
sed -i 's|c0a5af4ff9d0d540684c0bf00ef35dbe|744cbab090783905620da068c25e7f89|' opencv_2.4.3.bb
sed -i 's|f8fbe985978d4eae73e8c3b526ed40a37d4761d2029a5b035233f58146f6f59b|99786101446911cbb0c01761364c7c5eabd6a5df4f35cf88388dbec9bbd998c3|' opencv_2.4.3.bb

# UART patches
cd ${BSP_DIR}/meta-clanton-bsp/recipes-kernel/linux/files/
cp ${SCRIPT_DIR}/uart-1.0.patch .
echo 'SRC_URI += "file://uart-1.0.patch"' >> ../linux-yocto-clanton_3.8.bb

cd ${BSP_DIR}
# This patch must not exist within meta-clanton_v1.0.1
cp ${SCRIPT_DIR}/uart-reverse-8.patch ..
patch -p1 < ../uart-reverse-8.patch

# USB patch
cd ${BSP_DIR}/meta-clanton-distro/recipes-galileo/galileo-target/files/
cp ${SCRIPT_DIR}/1.usb_improv_patch-1.patch .
echo 'SRC_URI += "file://1.usb_improv_patch-1.patch"' >> ../galileo-target_0.1.bb

cd ${BSP_DIR}/meta-clanton-bsp/recipes-kernel/linux/files/
cp ${SCRIPT_DIR}/GAL-118-USBDeviceResetOnSUSRES-2.patch .
echo 'SRC_URI += "file://GAL-118-USBDeviceResetOnSUSRES-2.patch"' >> ../linux-yocto-clanton_3.8.bb
   
# CLLoader patch
cd ${BSP_DIR}/meta-clanton-distro/recipes-galileo/galileo-target/files/
cp ${SCRIPT_DIR}/2.GAL-193-clloader-1.patch .
echo 'SRC_URI += "file://2.GAL-193-clloader-1.patch"' >> ../galileo-target_0.1.bb
    
# SPI Upgrader patch
cd ${BSP_DIR}/meta-clanton-distro/recipes-galileo/galileo-target/files/
cp ${SCRIPT_DIR}/3.GAL-199-start_spi_upgrade-1.patch .
echo 'SRC_URI += "file://3.GAL-199-start_spi_upgrade-1.patch"' >> ../galileo-target_0.1.bb

# OpenSSL patch
cd ${BSP_DIR}/poky/meta/recipes-connectivity/openssl/
mv openssl-1.0.1e    openssl-1.0.1h
mv openssl_1.0.1e.bb openssl_1.0.1h.bb
sed -i 's|66bf6f10f060d561929de96f9dfe5b8c|8d6d684a9430d5cc98a62a5d8fbda8cf|' openssl_1.0.1h.bb
sed -i 's|f74f15e8c8ff11aa3d5bb5f276d202ec18d7246e95f961db76054199c69c1ae3|9d1c8a9836aa63e2c6adb684186cbd4371c9e9dcc01d6e3bb447abf2d4d3d093|' openssl_1.0.1h.bb
sed -i 's|file://openssl-fix-doc.patch||' openssl_1.0.1h.bb
sed -i 's|file://0001-Fix-for-TLS-record-tampering-bug-CVE-2013-4353.patch||' openssl_1.0.1h.bb
sed -i 's|file://0001-Fix-DTLS-retransmission-from-previous-session.patch||' openssl_1.0.1h.bb
sed -i 's|file://0001-Use-version-in-SSL_METHOD-not-SSL-structure.patch||' openssl_1.0.1h.bb
sed -i 's|file://CVE-2014-0160.patch||' openssl_1.0.1h.bb

# Wifi patch
cd ${BSP_DIR}/meta-clanton-distro/recipes-core/images
echo 'IMAGE_INSTALL += "linux-firmware-iwlwifi-6000g2b-6"' >> image-full.bb

# Sketch download patch
cd ${BSP_DIR}/meta-clanton-distro/recipes-galileo/galileo-target/files/
cp ${SCRIPT_DIR}/4.MAKER-222-Sketch_download_unstable-5.patch .
echo 'SRC_URI += "file://4.MAKER-222-Sketch_download_unstable-5.patch"' >> ../galileo-target_0.1.bb
